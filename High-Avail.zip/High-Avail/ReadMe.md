## Folder Compontents 
Netwrok.yml file and its parameteres 
Server.yml file and its parameters 

##  Load Balancer DNS Name is : 

http://Udiag-WebAp-7X5HXYQVD5JW-742877220.us-east-1.elb.amazonaws.com

## cheking Status:  is up and running 
iabrahaminternational.university